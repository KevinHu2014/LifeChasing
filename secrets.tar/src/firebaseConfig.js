const firebaseConfig = {
  apiKey: 'AIzaSyDoPwrBPZzs4gFjV3b7uPc-h2Z-OE1ua3Y',
  authDomain: 'life-chasing.firebaseapp.com',
  databaseURL: 'https://life-chasing.firebaseio.com',
  projectId: 'life-chasing',
  storageBucket: 'life-chasing.appspot.com',
  messagingSenderId: '286325310550',
};

export default firebaseConfig;
