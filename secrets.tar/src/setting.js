const setting = {
  weatherAPIKey: 'd4480eb4e80e03a03018d69c777c6333',
};
export default setting;
